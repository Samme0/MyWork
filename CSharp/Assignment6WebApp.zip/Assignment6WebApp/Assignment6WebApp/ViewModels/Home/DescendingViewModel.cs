﻿namespace Assignment6WebApp.ViewModels.Home
{
    public class DescendingViewModel
    {
        public string SortedSentences { get; set; } = string.Empty;
    }
}
