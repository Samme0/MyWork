﻿namespace Assignment6WebApp.ViewModels.Home
{
    public class IndexViewModel
    {
        public string Sentences { get; set; } = string.Empty;

        public string Message { get; set; } = string.Empty;
    }
}
