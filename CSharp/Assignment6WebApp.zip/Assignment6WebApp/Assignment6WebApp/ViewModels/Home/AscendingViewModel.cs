﻿namespace Assignment6WebApp.ViewModels.Home
{
    public class AscendingViewModel
    {
        public string SortedSentences { get; set; } = string.Empty;
    }
}
