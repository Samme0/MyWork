﻿namespace Assignment6WebApp.ViewModels.Home
{
    public class InitialLoadViewModel
    {
        public string InitialSentences { get; set; } = string.Empty;
    }
}
