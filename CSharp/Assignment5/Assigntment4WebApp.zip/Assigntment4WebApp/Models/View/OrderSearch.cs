﻿namespace Assigntment5WebApp.Models.View
{
    public class OrderSearch
    {
        public string SelectedBeverage { get; set; }
        public string SelectedAppetizer { get; set; }
        public string SelectedSandwich { get; set; }
        public string SelectedDessert { get; set; }
    }
}